package example.iest.edu.examen

import android.content.Context
import android.net.ConnectivityManager
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.Menu
import android.view.MenuItem
import android.widget.Toast
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import example.iest.edu.examen.adapters.OpcionAdapter
import example.iest.edu.examen.modelosclases.FakerOpciones

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val opciones=FakerOpciones().getOpciones()
        val recycler=findViewById<RecyclerView>(R.id.rvListado)
        val CANTIDAD_COLUMNAS=2
        var admistradorDeLayouts=GridLayoutManager(this,CANTIDAD_COLUMNAS)
        recycler.layoutManager=admistradorDeLayouts
        recycler.adapter=OpcionAdapter(opciones,this@MainActivity)

    }

    override fun onCreateOptionsMenu(menu: Menu?): Boolean {
        menuInflater.inflate(R.menu.menu,menu)
        return super.onCreateOptionsMenu(menu)
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        when (item.itemId) {
            R.id.wifi -> {
                val connectivityManager = getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
                val networkInfo = connectivityManager.activeNetworkInfo
                val isConnected = networkInfo != null && networkInfo.isConnectedOrConnecting
                if (networkInfo != null) {
                    if (isConnected && networkInfo.type == ConnectivityManager.TYPE_WIFI) {
                        Toast.makeText(this, "Conectado a wifi", Toast.LENGTH_SHORT).show()
                    } else {
                        Toast.makeText(this, "No está conectado a wifi", Toast.LENGTH_SHORT).show()
                    }
                }
                return true
            }
            else -> return super.onOptionsItemSelected(item)
        }
    }
}