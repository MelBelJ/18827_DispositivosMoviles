package example.iest.edu.examen

import android.content.Context
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.EditText
import com.google.android.material.floatingactionbutton.FloatingActionButton

class Perfil : AppCompatActivity() {
    lateinit var etNombreDueño: EditText
    lateinit var etNombreGato:EditText
    lateinit var etEdadGato:EditText
    lateinit var fab: FloatingActionButton

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_perfil)

        etNombreDueño = findViewById(R.id.etnombre_dueño)
        etNombreGato = findViewById(R.id.etnombre_gato)
        etEdadGato = findViewById(R.id.etedad_gato)
        fab = findViewById(R.id.fab)
        val prefs = getSharedPreferences("examen", Context.MODE_PRIVATE)
        etNombreDueño.setText(prefs.getString("nombre_dueño", ""))
        etNombreGato.setText(prefs.getString("nombre_gato", ""))
        etEdadGato.setText(prefs.getString("edad_gato", ""))
        fab.setOnClickListener(){
            guardar()
        }
    }

    fun guardar(){
        fab.setOnClickListener {
            val nombreDueño = etNombreDueño.text.toString()
            val nombreGato = etNombreGato.text.toString()
            val edadGato = etEdadGato.text.toString()

            val prefs = getSharedPreferences("examen", Context.MODE_PRIVATE)
            val editor = prefs.edit()
            editor.putString("nombre_dueño", nombreDueño)
            editor.putString("nombre_gato", nombreGato)
            editor.putString("edad_gato", edadGato)
            editor.apply()

            val intent = Intent(this, MainActivity::class.java)
            startActivity(intent)
            finish()
        }
    }
}