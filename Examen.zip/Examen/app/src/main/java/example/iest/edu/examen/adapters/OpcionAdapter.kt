package example.iest.edu.examen.adapters

import android.content.Context
import android.content.Intent
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.snackbar.Snackbar
import example.iest.edu.examen.Perfil
import example.iest.edu.examen.R
import example.iest.edu.examen.modelosclases.Opciones

class OpcionAdapter(opciones: ArrayList<Opciones>,context: Context): RecyclerView.Adapter<OpcionAdapter.Contenedordevista>() {
    var inner_opciones: ArrayList<Opciones> = opciones
    var inner_Context: Context = context

    inner class Contenedordevista(view: View):
        RecyclerView.ViewHolder(view){
                var opcionImagen: ImageView
                var opcionNombre: TextView
        init {
            //Acciones para cada opcion recuerda que es un ciclo y cada accion se asignara a cada opcion
            opcionImagen= view.findViewById(R.id.opcion_img)
            opcionNombre= view.findViewById(R.id.opcion_nombre)
            opcionImagen.setOnClickListener {
                val posicion=adapterPosition
                val opcion=inner_opciones[posicion]
                Snackbar.make(it,"Me seleccionaste ${opcion.nombreopcion}",Snackbar.LENGTH_SHORT).show()
                if(opcion.nombreopcion=="Perfil"){
                    val i= Intent(itemView.context,Perfil::class.java)
                    itemView.context.startActivity(i)
                }
                if(opcion.nombreopcion=="cerrar"){
                    (itemView.context as AppCompatActivity).finish()
                }
            }

        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): Contenedordevista {
        val view= LayoutInflater.from(parent.context).inflate(R.layout.opcion_item,parent,false)
        return Contenedordevista(view)
    }

    override fun getItemCount(): Int {
        return inner_opciones.size
    }

    override fun onBindViewHolder(holder: Contenedordevista, position: Int) {
        val opcion: Opciones=inner_opciones.get(position)
        holder.opcionImagen.setImageResource(opcion.image)
        holder.opcionNombre.text=opcion.nombreopcion
    }



}