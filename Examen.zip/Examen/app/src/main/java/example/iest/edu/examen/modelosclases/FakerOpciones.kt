package example.iest.edu.examen.modelosclases

import example.iest.edu.examen.R

class FakerOpciones {
    fun getOpciones():ArrayList<Opciones>{
        var opciones:ArrayList<Opciones>
        opciones= arrayListOf<Opciones>()

        var opcion=Opciones(R.drawable.cat,"Gatos",1)
        opciones.add(opcion)
         opcion=Opciones(R.drawable.profile,"Perfil",2)
        opciones.add(opcion)
         opcion=Opciones(R.drawable.config,"Configurar",3)
        opciones.add(opcion)
         opcion=Opciones(R.drawable.close,"cerrar",4)
        opciones.add(opcion)
        return opciones
    }
}