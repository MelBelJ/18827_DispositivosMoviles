package example.iest.edu.examen.modelosclases

data class Opciones(
    var image: Int,
    var nombreopcion: String,
    var idpcion: Int
)
